live_loop :G2022_03_28_108C do
  set_volume! 1
  use_bpm 100
  n0x = 24
  with_synth :tb303 do
    with_fx :slicer,
      phase: 1,
    pulse_width: 0.99 do
      with_fx :bitcrusher,
        bits: 5,
      sample_rate: 44000 do
        10.times do
          play n0x,
            amp: 1,
            attack: 0.001,
            sustain: 0.25*(ring 1,2).tick,
            release: 0.001,
            res: 0.0,
            wave: 0
          play n0x,
            amp: 1,
            attack: 0.001,
            sustain: 0.25*(ring 1,2).tick,
            release: 0.001,
            res: 0.0,
            wave: 1
          play n0x,
            amp: 1,
            attack: 0.001,
            sustain: 0.25*(ring 1,2).tick,
            release: 0.001,
            res: 0.0,
            wave: 2
          sleep 0.5
        end
      end
    end
  end
end
