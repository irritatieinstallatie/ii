live_loop :G2022_03_27_103C do
  n2 = 33
  s2 = 0.125
  use_bpm 100
  with_synth :tb303 do
    with_fx :bitcrusher, bits: 2,
    sample_rate: 44000 do
      with_fx :slicer, phase: 0.25, pulse_width: 0.25 do
        play n2+4, amp: 1,
          attack: 0.125,
          sustain: s2,
          release: 0.125,
          res: 0.125,
          wave: 0
        play n2+5, amp: 1,
          attack: 0.125,
          sustain: s2,
          release: 0.125,
          res: 0.125,
          wave: 2
        play n2+6, amp: 1,
          attack: 0.125,
          sustain: s2,
          release: 0.125,
          res: 0.125,
          wave: 2
        play n2+7, amp: 1,
          attack: 0.125,
          sustain: s2,
          release: 0.125,
          res: 0.125,
          wave: 2
        sleep (stretch [0.375],1,[0.125],10).tick
      end
    end
  end
end
