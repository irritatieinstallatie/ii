live_loop :G2022_03_10_093A_P do
  use_bpm 100
  n1 = 21
  n2 = 22
  with_synth :tb303 do
    with_fx :gverb, spread: 0.5, dry: 3, room: 33 do
      with_fx :bitcrusher,
        bits: 4,
      sample_rate: 44000 do
        10.times do
          play n1,
            amp: (ring 1,4).tick,
            attack: 0.25,
            sustain: 1,
            release: 0.25,
            wave: 2
          play n1+0.25, amp: 1,
            attack: 0.25,
            sustain: 1,
            release: 0.25,
            wave: 2
          play n1+0.5,
            amp: rrand(0,1),
            attack: 0.25,
            sustain: 1,
            release: 0.25,
            wave: 2
          play n2,
            amp: 1,
            attack: 0.25,
            sustain: 1,
            release: 0.25,
            wave: 2
          sleep 0.5
        end
      end
    end
  end
end
