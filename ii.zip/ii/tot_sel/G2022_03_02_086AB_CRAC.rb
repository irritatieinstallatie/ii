live_loop :G2022_01_07_017E do
  use_bpm 100
  n0 = rrand_i(1,6)
  t0r0 = rrand_i(15,35)
  with_synth :tb303 do
    with_fx :gverb, spread: 0.75, dry: 1, room: 55 do
      with_fx :slicer, phase: 0.375, pulse_width: 0.375 do
        with_fx :bitcrusher,
        bits: (ring 1,1,1,1,2,3,4,5).choose do
          n0.times do
            play 70, amp: rrand_i(2,4),
              attack: 0.01, attack_level: 0.75,
              sustain: 0.0125, decay: 0.0125,
              decay_level: 0.0125,release: 0.05
            play 71, amp: rrand_i(2,4),
              attack: 0.01, attack_level: 0.75,
              sustain: 0.0125, decay: 0.0125,
              decay_level: 0.0125,release: 0.05
            sleep 0.25
          end
        end
      end
    end
  end
end



live_loop :G2022_02_08_067A do
  use_bpm 100
  with_synth :tb303 do
    20.times do
      play 29.125,
        amp: (ring 2,2,2,1).tick,
        attack: 0.005,
        release: 0.75,
        res: (line 0.1, 0.8, steps: 8).mirror.tick,
        wave: 2
      play 29,
        #        amp: (line 0,2, steps: 10).mirror.tick,
        attack: 0.005,
        release: 0.75,
        res: (line 0.1, 0.8, steps: 8).mirror.tick,
        wave: 2
      play 29.25,
        amp: (ring 2,1,2,2).tick,
        attack: 0.005,
        release: 0.75,
        res: (line 0.1, 0.8, steps: 8).mirror.tick,
        wave: 2
      play 29.5,
        #       amp: (line 0,2, steps: 10).mirror.tick,
        attack: 0.005,
        release: 0.75,
        res: (line 0.1, 0.8, steps: 8).mirror.tick,
        wave: 2
      sleep 0.25
    end
  end
end
