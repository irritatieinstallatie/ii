
live_loop :G2022_02_21_082A do
  with_synth :tb303 do
    20.times do
      play 44, amp: 1,
        attack: 0.01,
        sustain: 0.125,
        release: 0.01,
        res: 0.75,
        wave: 2
      play 33, amp: 1,
        attack: 0.01,
        sustain: 0.5,
        release: 0.01,
        res: 0.99,
        wave: 2
      sleep 0.25
    end
  end
end

