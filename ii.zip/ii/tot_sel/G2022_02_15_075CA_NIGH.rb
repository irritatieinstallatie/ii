live_loop :G2022_02_11_075CF do
  use_bpm 100
  n1 = rrand_i(28,29)
  n2 = rrand_i(29,30)
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: 3,
    sample_rate: 44000 do
      21.times do
        play n1, amp: (ring 1,4).tick,
          attack: 0.05,
          sustain: (stretch [0.5],1,[1],6).tick,
          release: 0.05,
          wave: 2
        play n1+0.25, amp: 1,
          attack: 0.05,
          sustain: (stretch [1],1,[0.25],6).tick,
          release: 0.05,
          wave: 2
        play n1+0.5,
          amp: rrand(0,1),
          attack: 0.001,
          sustain: (stretch [0.5],1,[0.25],6).tick,
          release: 0.001,
          wave: 0
        play n2,
          amp: 1,
          attack: 0.05,
          sustain: (stretch [0.25],1,[1],6).tick,
          release: 0.05,
          wave: 2
        sleep 0.5
      end
    end
  end
end
