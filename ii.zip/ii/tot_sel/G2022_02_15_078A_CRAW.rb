live_loop :G2022_02_15_078A do
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: rrand_i(1,3),
    pre_amp: 0.5 do
      8.times do
        play 32, amp: rrand(1,2),
          attack: 0.001,
          sustain: 0.25,
          release: 0.001,
          res: rrand(0,1),
          wave: 2
        play 44, amp: 1,
          attack: 0.001,
          sustain: 0.25,
          release: 0.001,
          res: 0.75,
          wave: 2
        play rrand_i(31,33), amp: 1,
          attack: 0.001,
          sustain: 0.25,
          release: 0.001,
          res: 0.75,
          wave: 2
        play 31, amp: 2,
          attack: 0.001,
          sustain: 0.25,
          release: 0.001,
          res: 0.5,
          wave: 2
        sleep (stretch [0.25],4,[0.125],4).mirror.tick
      end
    end
  end
end
