live_loop :G2022_03_27_103F do
  set_volume! 1.0
  n2 = 26
  s2 = 0.05
  use_bpm 100
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: rrand_i(1,16),
    sample_rate: 44000 do
      with_fx :gverb,
        spread: 0.5,
        dry: (line 2,12,steps: 10)
	  .choose,
      room: 44 do
        8.times do
          play n2+4, amp: 1,
            attack: 0.0125,
            sustain: s2,
            release: 0.25,
            res: 0.99,
            wave: 1
          play n2+5, amp: 1,
            attack: 0.0125,
            sustain: s2,
            release: 0.25,
            res: 0.99,
            wave: 1
          play n2+6, amp: 1,
            attack: 0.0125,
            sustain: s2,
            release: 0.25,
            res: 0.99,
            wave: 1
          play n2+7, amp: 1,
            attack: 0.0125,
            sustain: s2,
            release: 0.25,
            res: 0.99,
            wave: 1
          sleep 0.25
        end
      end
    end
  end
end
