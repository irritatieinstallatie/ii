live_loop :G2022_01_29_051E do
  use_bpm 100
  n0x0 = 40
  lx0 = 4*rrand_i(1,4)
  with_synth :tb303 do
    with_fx :slicer, phase: 0.99,
      pulse_width: (stretch [0.75],4,
                    [0.99],4
    ).tick do
      lx0.times do
        play n0x0-0.1, amp: 4,
          attack: 0.001,
          sustain: 0.25,
          release: 0.001,
          pulse_width: 0.3,
          res: 0.2,
          wave: 2
        play n0x0, amp: 8,
          attack: 0.001,
          sustain: 0.25,
          release: 0.001,
          pulse_width: 0.3,
          res: 0.2,
          wave: 1
        play n0x0+0.1, amp: 4,
          attack: 0.001,
          sustain: 0.25,
          release: 0.001,
          pulse_width: 0.3,
          res: 0.2,
          wave: 2
        sleep 0.25
      end
      #      sleep rrand(0,0.875)
    end
  end
end
