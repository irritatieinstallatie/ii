live_loop :G2022_02_27_085A do
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: (ring 3,4,5).tick,
    sample_rate: 44000 do
      16.times  do
        play 25,
          amp: 1,
          attack: 0.5,
          sustain: 0.5,
          release: 0.01,
          res: 0.5,
          wave: 2
        play 30,
          amp: 1,
          attack: 0.5,
          sustain: 0.5,
          release: 0.01,
          res: 0.5,
          wave: 2
        sleep (stretch [0.25], rrand_i(2,4),
               [0.5], rrand_i(2,4),
               [0.75], rrand_i(2,4),
               [1],rrand_i(2,4),).tick
      end
    end
  end
end
