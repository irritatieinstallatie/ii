
live_loop :G2022_01_29_051A do
  use_bpm 100
  n0x0 = 33
  lx0 = rrand_i(2,4)
  with_synth :tb303 do
    lx0.times do
      play n0x0-0.1, amp: 4, attack: 0.001, sustain: 0.25, release: 0.001, wave: 1
      play n0x0, amp: 4, attack: 0.001,
        sustain: (stretch [0.375],14,
                  [0.5],2).tick,
        release: 0.5, wave: 1
      play n0x0+0.1, amp: 4, attack: 0.001, sustain: 0.25, release: 0.001, wave: 1
      sleep (stretch [0.5],14,[0.25],5).tick
    end
  end
end
live_loop :G2022_01_29_051B do
  use_bpm 100
  n0x0 = 33
  lx0 = rrand_i(2,4)
  with_synth :tb303 do
    lx0.times do
      play n0x0-0.1, amp: (line 0,4, steps: 4).mirror.tick, attack: 0.001, sustain: 0.25, release: 0.001, wave: 1
      play n0x0, amp: (line 0,4, steps: 2).mirror.tick, attack: 0.001,
        sustain: (stretch [0.375],14,
                  [0.5],5).tick,
        release: 0.5, wave: 1
      play n0x0+0.1, amp: (line 0,4, steps: 2).mirror.tick, attack: 0.001, sustain: 0.25, release: 0.001, wave: 1
      sleep (stretch [0.5],14,[0.25],5).tick
    end
  end
end
