live_loop :G2022_02_11_075C do
  set_volume! 1
  use_bpm 100
  n1 = 28
  n2 = 29
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: rrand_i(2,7),
    sample_rate: 44000 do
      8.times do
        play n1, amp: (ring 0,4).tick,
          attack: 0.05,
          sustain: 4*(ring 0.125,0.25,0.25,0.125).tick,
          release: 0.05,
          wave: 2
        play n1+0.25, amp: 3,
          attack: 0.05,
          sustain: 4*(ring 0.125,0.25,0.25,0.125).tick,
          release: 0.05,
          wave: 2
        play n1+0.5,
          amp: (ring 12,0).tick,
          attack: 0.05,
          sustain: 2*(ring 0.125,0.25,0.25,0.125).tick,
          release: 0.05,
          wave: 0
        play n2,
          amp: 1,
          attack: 0.05,
          sustain: 4*(ring 0.125,0.25,0.25,rrand(0.125,0.5)).tick,
          release: 0.05,
          wave: 2
        sleep 0.5
      end
    end
  end
end
