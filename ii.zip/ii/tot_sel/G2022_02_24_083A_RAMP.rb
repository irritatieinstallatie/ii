live_loop :G2022_02_24_083A do
  use_bpm 100
  with_synth :mod_saw do
    with_fx :gverb, room: (line 20, 30, steps: 20).choose do
      with_fx :slicer,
        phase: (stretch [0.125],3,
                [0.99],3
                ).tick,
        pulse_width: (stretch [0.25],3,
                      [0.99],3
      ).tick do
        3.times do
          play 28, sustain: 3
          play 57, sustain: 3
          play 66, sustain: 3
          sleep 1
        end
        3.times do
          play 57, sustain: 3
          play 38, sustain: 3
          play 65, sustain: 3
          sleep 1
        end
        3.times do
          play rrand(54, 62), sustain: 9
          play rrand(37,41), sustain: 9
          play rrand(61,66), sustain: 9
          sleep 7
        end
      end
    end
  end
end
