live_loop :G2022_02_24_083B do
  use_bpm 100
  with_synth :mod_saw do
    with_fx :gverb, room: (line 20, 30, steps: 20).choose do
      with_fx :slicer,
        phase: (stretch [0.5],1,
                [0.25],1,
                [0.99],3
                ).tick,
        pulse_width: (stretch [0.5],1,
                      [0.25],1,
                      [0.99],3
      ).tick do
        3.times do
          play 27, sustain: 1
          play 38, sustain: 1
          play 65, sustain: 1
          sleep 1
        end
        3.times do
          play 28, sustain: 1
          play 37, sustain: 1
          play 66, sustain: 1
          sleep 1
        end
        3.times do
          if one_in(2)
            play (ring rrand(54, 62), rrand(37,41), rrand(61,66)), sustain: 1
            play rrand(54, 62), sustain: 1
            sleep 1
          else
            play rrand(37,41), sustain: 1
            play rrand(61,66), sustain: 1
            sleep 1
          end
        end
      end
    end
  end
end
