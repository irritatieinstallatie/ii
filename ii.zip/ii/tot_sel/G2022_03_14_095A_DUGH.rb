live_loop :G2022_03_14_095A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :bitcrusher, mix: rrand_i(0,1),
      bits: (ring 4,3,2).choose,
    sample_rate: 44000 do
      20.times do
        play 28,
          amp: 1,
          attack: 0.125,
          sustain: 0.125,
          release: 0.125,
          wave: 2
        play 29,
          amp: 1,
          attack: 0.125,
          sustain: 0.125,
          release: 0.125,
          wave: 2
        play 40,
          amp: 1,
          attack: 0.1,
          sustain: 0.125,
          release: 0.1,
          wave: 2
        play rrand_i(40,44),
          amp: 1,
          attack: 0.1,
          sustain: 0.125,
          release: 0.1,
          wave: 2
        sleep (stretch [0.25], rrand_i(5,10),
               [0.25],rrand_i(5,10)
               ).tick
      end
    end
  end
end
