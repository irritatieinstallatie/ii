live_loop :G2022_03_04_089A do
  set_volume! 1
  rn1 = rrand_i(9,12)
  use_bpm 120
  with_synth :tb303 do
    with_fx :gverb, room: 77 do
      with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
        rn1.times do
          with_fx :bitcrusher,
            bits: 3,
          sample_rate: rrand(440,44000) do
            play 29,
              amp: 1.5,
              attack: 0.0125,
              sustain: 0.5,
              decay: 0,
              release: 0.05,
              wave: 2,
              res: 0.05
            sleep 0.5
          end
        end
      end
    end
  end
end
