live_loop :G2022_02_15_077A do
  with_synth :tb303 do
    play 33, amp: 1,
      attack: 0.001,
      sustain: 0.5,
      release: 0.001,
      wave: 2
    play 45, amp: 1,
      attack: 0.001,
      sustain: 0.5,
      release: 0.001,
      wave: 2
    sleep 0.25
  end
end
live_loop :G2022_02_15_077B do
  with_synth :piano do
    with_fx :bitcrusher, bits: rrand_i(3,7), sample_rate: 44000 do
      with_fx :krush, mix: rrand(0,1),
      res: 0.25 do
        10.times do
          play 31, amp: 1,
            sustain: 0.5,
            vel: 0.25,
            hard: 0.5
          play 34, amp: 1,
            sustain: 0.5,
            vel: 0.25,
            hard: 0.5
          sleep 0.25
        end
      end
    end
  end
end
