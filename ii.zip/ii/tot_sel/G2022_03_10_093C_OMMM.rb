live_loop :G2022_03_10_093C_P do
  use_random_seed 101
  use_bpm 100
  n1 = 22
  n2 = 29
  with_synth :tb303 do
    with_fx :bitcrusher,
    bits: rrand_i(1,6) do
      18.times do
        play n1,
          amp: (ring 1,4).tick,
          attack: 0.05,
          sustain: (stretch [0.5],4,[1],4).reflect.tick,
          release: 0.05,
          res: 0.5,
          wave: 2
        play n1+0.25, amp: 1,
          attack: 0.05,
          sustain: (stretch [0.5],4,[1],1,[0.5],1).reflect.tick,
          release: 0.05,
          res: 0.5,
          wave: 2
        play n1+0.5,
          amp: rrand(0,1),
          attack: 0.001,
          sustain: (stretch [0.5],4,[1],6,[0.25],2,[0.5],1).reflect.tick,
          release: 0.001,
          res: 0.5,
          wave: 2
        play n2,
          amp: 1,
          attack: 0.01,
          sustain: (stretch [0.25],2,[1],2,[0.25],1).reflect.tick,
          release: 0.01,
          res: 0.5,
          wave: 2
        sleep 0.5
      end
    end
  end
end
