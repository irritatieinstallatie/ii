live_loop :G2022_03_31_1709_111A do
  with_synth :tb303 do
    with_fx :slicer,
    pulse_width: 0.25, phase: 0.125 do
      play 30, amp: 2,
        attack: 0.001,
        decay: 0.0,
        sustain: 8,
        release: 0.001
      play 50, amp: 2,
        attack: 0.001,
        decay: 0.0,
        sustain: 8,
        release: 0.001
      sleep 1
    end
  end
end
