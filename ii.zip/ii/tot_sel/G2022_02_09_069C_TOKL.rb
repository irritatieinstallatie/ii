live_loop :G2022_02_10_069C do
  use_bpm 100
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: (ring 2).tick,
    sample_rate: 44000 do
      8.times do
        play 36,
          amp: 1,
          sustain: rrand(0,1),
          res: 0.1,
          wave: 2
        play 48,
          amp: (line 0,1, steps: 4).mirror.tick,
          sustain: rrand(0,1),
          res: 0.1,
          wave: 2
        sleep 0.25
      end
    end
  end
end
