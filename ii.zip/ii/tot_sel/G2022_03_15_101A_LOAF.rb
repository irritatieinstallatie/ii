live_loop :G2022_03_15_101A do
  use_bpm 100
  set_volume! 0.5
  n0 = 21
  n1 = 56
  n2 = 60
  n3 = 71
  a1 = 0.05
  d1 = 0.125
  s1 = 0.25
  r1 = 0.05
  with_synth :tb303 do
    with_fx :gverb, spread: 0.125, dry: 1, room: 55 do
      with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
        with_fx :bitcrusher, bits: 2 do
          2.times do
            play n0, amp: 1,
              attack: a1*2,
              sustain: s1*2,
              release: r1*2,
              wave: 2
            play n1, amp: 1,
              attack: a1,
              sustain: s1,
              release: r1,
              wave: 2
            play n1+2,
              amp: 1,
              attack: a1,
              sustain: s1,
              release: r1,
              wave: 2
            play n1+2.25,
              amp: 1,
              attack: a1,
              sustain: s1,
              release: r1,
              wave: 2
            play n2,
              amp: 1,
              attack: a1,
              sustain: s1,
              release: r1,
              decay: d1,
              wave: 2
            play n3,
              amp: 1,
              attack: a1*0.5,
              sustain: s1*0.5,
              decay: d1,
              release: r1*0.5,
              wave: 2
            sleep 0.5
          end
        end
      end
    end
  end
end
