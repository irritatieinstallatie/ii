live_loop :G2022_02_08_069A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: 3,
    sample_rate: 4400 do
      8.times do
        play 36,
          amp: (line 0,1, steps: 8).choose,
          sustain: 0.5,
          res: 0.1,
          wave: 2
        play 43,
          amp: (line 0,1, steps: 8).choose,
          sustain: 0.5,
          res: 0.1,
          wave: 2
        sleep 0.5
      end
    end
  end
end
live_loop :G2022_02_08_069B do
  use_bpm 100
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: 3,
    sample_rate: 44000 do
      8.times do
        play 36,
          amp: (line 0,1, steps: 8).choose,
          sustain: 0.5,
          res: 0.1,
          wave: 2
        with_fx :slicer, phase: 0.5, pulse_width: 0.125 do
          play 70,
            amp: rrand(2,0),
            sustain: 2,
            res: 0.1,
            wave: 0
          sleep 0.25
        end
      end
    end
  end
end
