live_loop :G2022_02_13_076BA do
  ss1 = rrand(0.125,0.25)
  lor0 = rrand_i(2,4)
  use_bpm 100
  with_synth :tb303 do
    with_fx :bitcrusher, bits: rrand_i(1,6), sample_rate: 44000 do
      lor0.times do
        play 40,
          amp: 1,
          attack: 0.001,
          sustain: 0.1875,
          release: 0.001,
          res: 0.125,
          wave: 1
        play 41,
          amp: 1,
          attack: 0.01,
          sustain: 0.25,
          release: 0.01,
          #           res: 0.75,
          wave: 2
        sleep 0.25
      end
    end
  end
end
