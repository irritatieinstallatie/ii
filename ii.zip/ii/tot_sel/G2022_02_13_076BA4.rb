live_loop :G2022_02_13_076BA4 do
  lor0 = rrand_i(1,4)
  use_bpm 100
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: 2,
    sample_rate: 44000 do
      lor0.times do
        play 40,
          amp: 1,
          attack: 0.001,
          sustain: 0.25,
          release: 0.001,
          res: 0.75,
          wave: 2
        play 41,
          amp: 1,
          attack: 0.001,
          sustain: 0.125,
          release: 0.001,
          res: 0.75,
          wave: 2
        sleep 0.5
      end
    end
  end
end
