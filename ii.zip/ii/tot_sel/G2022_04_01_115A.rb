live_loop :G2022_04_01_115A do
  use_random_seed 105
  use_bpm 100
  n1 = 41
  n2 = 42
  n3 = 48
  n0 = rrand_i(5,10)
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: (line 1,6, steps: n0).look,
      sample_rate: 44000,
    cutoff: (line 65, 130, steps: n0).choose do
      n0.times do
        play n1,
          amp: (ring 1,2).look,
          attack: 0.25,
          decay: 0.05,
          sustain: 0.25,
          release: 0.5,
          res: 0.125,
          wave: 2
        play n1+0.25,
          amp: (ring 1,2).look,
          amp: 1,
          attack: 0.25,
          decay: 0.05,
          sustain: 0.25,
          release: 0.5,
          res: 0.125,
          wave: 2
        play n1+0.5,
          amp: (ring 0,1).look,
          decay: 0.05,
          attack: 0.25,
          sustain: 0.25,
          release: 0.5,
          res: 0.125,
          wave: 2
        play n1+0.75,
          amp: 2,
          attack: 0.25,
          decay: 0.05,
          sustain: 0.25,
          release: 0.5,
          res: 0.125,
          wave: 2
        play n2,
          amp: (ring 0,1).look,
          attack: 0.25,
          decay: 0.001,
          sustain: 0.25,
          release: 0.25,
          res: 0.125,
          wave: 2
        play n3,
          amp: (ring 1,2).look,
          attack: 0.25,
          decay: 0.001,
          sustain: 0.25,
          release: 0.25,
          res: 0.125,
          wave: 2
        sleep (stretch [0.5], 8, [0.125], 1).tick
      end
    end
  end
end


