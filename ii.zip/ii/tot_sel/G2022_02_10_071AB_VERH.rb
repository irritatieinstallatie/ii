live_loop :G2022_02_10_071A do
  n01 = rrand_i(10,20)
  n66 = 66
  #  use_random_seed 101
  use_bpm 100
  with_synth :tb303 do
    with_fx :slicer, phase: 0.25, pulse_width: 0.125 do
      n01.times do
        play n66,
          #          amp: rrand(0.01,0.99),
          sustain: 0.5,
          res: 0.5,
          wave: 2
        play n66+0.5,
          #         amp: rrand(0.01,0.99),
          sustain: 0.5,
          res: 0.5,
          wave: 2
        play n66+1,
          #        amp: rrand(0,1),
          sustain: 0.5,
          res: 0.5,
          wave: 2
        sleep 0.25
    end    end
  end
end

live_loop :G2022_02_10_071B do
  n01 = rrand_i(10,20)
  # use_random_seed 101
  use_bpm 100
  with_synth :tb303 do
    with_fx :slicer, phase: 1, pulse_width: 0.99 do
      n01.times do
        play 53,
          #       amp: rrand(0,1),
          attack: 0.01,
          sustain: rrand(0.5,1.5),
          release: 0.01,
          res: 0.5,
          wave: rrand_i(0,2)
        play 54,
          #      amp: rrand(0,1),
          attack: 0.01,
          sustain: rrand(0.5,1.5),
          release: 0.01,
          res: 0.5,
          wave: rrand_i(0,2)
        play 38,
          #     amp: rrand(0,1),
          attack: 0.01,
          sustain: rrand(0.5,1.5),
          release: 0.01,
          res: 0.5,
          wave: rrand_i(0,2)
        play rrand(37.875,38.125),
          #    amp: rrand(0,1),
          attack: 0.01,
          sustain: rrand(0.5,1.5),
          release: 0.01,
          res: 0.5,
          wave: rrand_i(0,2)
        sleep 0.25
      end
    end
  end
end
