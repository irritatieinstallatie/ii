live_loop :G2022_03_09_092A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :bitcrusher, bits: 4 do
      play 32, amp: 1,
        attack: 0.125,
        sustain: 1,
        release: 0.125,
        wave: 2
      play 35, amp: 1,
        attack: 0.25,
        sustain: 1,
        release: 0.25,
        wave: 2
      play 29, amp: 1,
        attack: 0.25,
        sustain: 1,
        release: 0.25,
        wave: 2
      sleep (stretch [0.25], 10,
             [0.5], 10,
             [1],10).mirror.tick
    end
  end
end
