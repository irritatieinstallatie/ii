live_loop :G2022_03_10_093E_P do
  #  use_random_seed 101
  use_bpm 100
  n1 = 22
  n2 = 26
  with_synth :tb303 do
    with_fx :bitcrusher,
    bits: rrand_i(2,6) do
      12.times do
        play n1,
          amp: 1,
          attack: 0.25,
          sustain: 1,
          release: 0.25,
          wave: 2
        play n1+0.25, amp: 1,
          attack: 0.25,
          sustain: 1,
          release: 0.25,
          wave: 2
        play n1+0.5,
          amp: 1,
          attack: 0.25,
          sustain: 1,
          release: 0.25,
          wave: 2
        play n2,
          amp: 2,
          attack: 0.25,
          sustain: 1,
          release: 0.25,
          wave: 2
        sleep 0.5
      end
    end
  end
end
