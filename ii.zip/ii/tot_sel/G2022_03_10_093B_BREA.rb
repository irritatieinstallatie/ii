live_loop :G2022_03_10_093B_P do
  use_bpm 100
  n1 = 59
  n2 = 29
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: rrand_i(1,4),
    sample_rate: 44000 do
      10.times do
        play n1,
          amp: 1,
          attack: 0.25,
          sustain: 1,
          release: 0.25,
          wave: 0
        play n1-0.125, amp: 1,
          attack: 0.25,
          sustain: 1,
          release: 0.25,
          wave: 0
        play n1+0.125,
          amp: 1,
          attack: 0.25,
          sustain: 1,
          release: 0.25,
          wave: 0
        play n2,
          amp: 1,
          attack: 0.125,
          sustain: 1,
          release: 0.125,
          wave: 0
        play n2,
          amp: 1,
          attack: 0.125,
          sustain: 1,
          release: 0.125,
          wave: 2
        sleep 0.5
      end
    end
  end
end
