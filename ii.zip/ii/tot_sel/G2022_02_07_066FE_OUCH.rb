live_loop :G2022_02_07_066FE do
  use_bpm 100
  with_synth :piano do
    with_fx :slicer,
      phase: 0.5,
    pulse_width: 0.25 do
      play 33, amp: rrand_i(1,2),
        attack: 0.001,
        sustain: 0.25,
        release: 0.001,
        wave: 2,
        vel: 0.75,
        hard: 0.75
      play 69, amp: rrand_i(1,2),
        attack: 0.001,
        sustain: 0.25,
        release: 0.001,
        wave: 2,
        vel: 0.75,
        hard: 0.75
      play 77, amp: rrand_i(1,2),
        attack: 0.001,
        sustain: 0.25,
        release: 0.001,
        wave: 2,
        vel: 0.75,
        hard: 0.75
      play 44, amp: rrand_i(1,2),
        attack: 0.001,
        sustain: 0.25,
        release: 0.001,
        wave: 2,
        vel: 0.75,
        hard: 0.75
      sleep 0.25
    end
  end
end
