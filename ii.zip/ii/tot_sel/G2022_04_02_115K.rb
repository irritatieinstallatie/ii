
live_loop :G2022_04_02_115K do
  use_bpm 100
  n1 = 22
  n2 = 24
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: (ring 4,3,2).choose,
    sample_rate: 44000 do
      20.times do
        play n1,
          amp: 1,
          attack: 0.005,
          sustain: 0.5,
          release: 0.005,
          res: 0.009,
          wave: 2
        play n1+0.25,
          amp: rrand_i(0,1),
          attack: 0.005,
          sustain: 0.5,
          release: 0.005,
          res: 0.009,
          wave: 2
        play n1+0.5,
          amp: rrand_i(0,1),
          attack: 0.005,
          sustain: 0.5,
          release: 0.005,
          res: 0.009,
          wave: 2
        play n1+0.75,
          amp: rrand_i(0,1),
          attack: 0.005,
          sustain: 0.5,
          release: 0.005,
          res: 0.009,
          wave: 2
        play n2,
          amp: 1,
          attack: 0.00125,
          sustain: 0.675,
          release: 0.25,
          res: 0.009,
          wave: 2
        sleep (stretch [0.5], rrand_i(5,10),
               [0.25],rrand_i(5,10)
               ).tick
      end
    end
  end
end

