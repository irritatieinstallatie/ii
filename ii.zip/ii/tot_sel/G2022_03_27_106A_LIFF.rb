live_loop :G2022_03_14_106A do
  set_volume! 1
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, 
spread: 0.05, 
dry: 22,
    room: 88 do
      with_fx :slicer, 
phase: 0.25, 
pulse_width: 0.25 do
        play 59,
          amp: 1,
          attack: 0.125,
          sustain: 0.5,
          release: 0.125,
          res: 0.99,
          wave: 2
        play 52,
          amp: 1,
          attack: 0.125,
          sustain: 0.5,
          release: 0.125,
          res: 0.99,
          wave: 2
        play 53,
          amp: 1,
          attack: 0.125,
          sustain: 0.25,
          release: 0.125,
          res: 0.99,
          wave: 2
        play 54,
          amp: 1,
          attack: 0.125,
          sustain: 0.5,
          release: 0.125,
          res: 0.99,
          wave: 1
        sleep 0.5
      end
    end
  end
end
