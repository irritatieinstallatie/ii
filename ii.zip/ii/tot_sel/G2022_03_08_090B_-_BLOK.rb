live_loop :G2022_02_21_081C do
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: (ring 3,4).choose,
    sample_rate: 44000 do
      4.times  do
        play 30,
          amp: 2,
          attack: 0.01,
          sustain: 0.125,
          release: 0.01,
          res: 0.5,
          wave: 2
        play 25,
          amp: 2,
          attack: 0.1,
          sustain: 0.125,
          release: 0.1,
          res: 0.5,
          wave: 2
        sleep 0.25
      end
      sleep rrand_i(0,1)*0.125
    end
  end
end
