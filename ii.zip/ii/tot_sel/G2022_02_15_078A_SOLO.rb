live_loop :G2022_02_15_078A_SOLO do
  use_bpm 100
  with_synth :tb303 do
    10.times do
      play 33,
        amp: 1,
        attack: 0.025,
        sustain: 0.125,
        release: 0.025,
        res: 0.75,
        wave: 2
      play 41,
        amp: 1,
        attack: 0.025,
        sustain: 0.125,
        release: 0.025,
        res: 0.75,
        wave: 2
      sleep 0.25
    end
  end
end
